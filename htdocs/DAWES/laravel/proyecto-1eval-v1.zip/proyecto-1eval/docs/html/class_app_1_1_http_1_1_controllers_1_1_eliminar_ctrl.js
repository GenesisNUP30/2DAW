var class_app_1_1_http_1_1_controllers_1_1_eliminar_ctrl =
[
    [ "confirmar", "class_app_1_1_http_1_1_controllers_1_1_eliminar_ctrl.html#ae03ac098b4c5a565b5b52a352cc95253", null ],
    [ "eliminar", "class_app_1_1_http_1_1_controllers_1_1_eliminar_ctrl.html#a83712803f2a57af348a282f0a73cd2ce", null ]
];