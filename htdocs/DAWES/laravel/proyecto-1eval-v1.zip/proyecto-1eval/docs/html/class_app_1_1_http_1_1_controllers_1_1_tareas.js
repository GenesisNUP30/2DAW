var class_app_1_1_http_1_1_controllers_1_1_tareas =
[
    [ "__construct", "class_app_1_1_http_1_1_controllers_1_1_tareas.html#a24d0e8e3dbbb16cfe28af07ddc417a0c", null ],
    [ "actualizarTarea", "class_app_1_1_http_1_1_controllers_1_1_tareas.html#aec498f8212a895990c27600b4965d86c", null ],
    [ "completarTarea", "class_app_1_1_http_1_1_controllers_1_1_tareas.html#aa502c3e0b2c13b544ee13470a18a1118", null ],
    [ "eliminarTarea", "class_app_1_1_http_1_1_controllers_1_1_tareas.html#a9bae485ace8ae02392979a5875f75daf", null ],
    [ "listarTareas", "class_app_1_1_http_1_1_controllers_1_1_tareas.html#a2af0eaab61563699ff499aeaab9cdae2", null ],
    [ "obtenerTareaPorId", "class_app_1_1_http_1_1_controllers_1_1_tareas.html#a12f50437cc7dd725b4f8e5cb3f7a4ef2", null ],
    [ "registraAlta", "class_app_1_1_http_1_1_controllers_1_1_tareas.html#ac5b8326ec3b6e12b42b1900290b147f7", null ],
    [ "$bd", "class_app_1_1_http_1_1_controllers_1_1_tareas.html#a0b24fec2d479d380e103a24627ff0592", null ]
];