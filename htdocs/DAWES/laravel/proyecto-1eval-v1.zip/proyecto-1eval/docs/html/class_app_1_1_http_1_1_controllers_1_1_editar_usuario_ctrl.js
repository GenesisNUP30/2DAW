var class_app_1_1_http_1_1_controllers_1_1_editar_usuario_ctrl =
[
    [ "actualizar", "class_app_1_1_http_1_1_controllers_1_1_editar_usuario_ctrl.html#a39260d89d62595041604e2adac5f7dcd", null ],
    [ "filtraDatos", "class_app_1_1_http_1_1_controllers_1_1_editar_usuario_ctrl.html#ad37faa14a2c149ce9c965d6986ee6e2c", null ]
];