var class_app_1_1_http_1_1_controllers_1_1_inicio_ctrl =
[
    [ "index", "class_app_1_1_http_1_1_controllers_1_1_inicio_ctrl.html#a3893c71a0ffefcd47a327907f7507b6b", null ],
    [ "verTarea", "class_app_1_1_http_1_1_controllers_1_1_inicio_ctrl.html#ae187e03505a2fdab2f893fc53812ff6c", null ]
];