var class_inicio_ctrl =
[
    [ "index", "class_inicio_ctrl.html#a3893c71a0ffefcd47a327907f7507b6b", null ],
    [ "verTarea", "class_inicio_ctrl.html#af6b3024af40df40840e38e4770cb16bb", null ]
];