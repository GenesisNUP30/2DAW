var searchData=
[
  ['yield_0',['yield',['../plantilla01_8blade_8php.html#aa94b7ff24a66c590ae37f6f3f3abe8f9',1,'yield(&apos;titulo&apos;)&lt;/title &gt;&lt;!-- Estilos generales - -&gt;&lt; style &gt; body:&#160;plantilla01.blade.php'],['../plantilla01_8blade_8php.html#a3d888adb1603b1ab4077234abb60b9f8',1,'yield(&apos;estilos&apos;)&lt;/head &gt;&lt; body &gt;&lt;!-- HEADER - -&gt;&lt; div class=&quot;header-app d-flex justify-content-between align-items-center&quot;&gt;&lt; h4 class=&quot;m-0&quot;&gt;&lt; i class=&quot;fas fa-clipboard-check&quot;&gt;&lt;/i &gt; Gestor de tareas&lt;/h4 &gt; @if(!empty($_SESSION[&apos;logado&apos;]))&lt; div &gt;&lt; i class=&quot;fas fa-user&quot;&gt;&lt;/i &gt;:&#160;plantilla01.blade.php']]]
];
