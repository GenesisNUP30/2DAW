var searchData=
[
  ['usuarioexiste_0',['usuarioExiste',['../class_app_1_1_models_1_1_usuarios.html#ab246090a67081dfc99d32d2382f23cf5',1,'App::Models::Usuarios::usuarioExiste()'],['../class_app_1_1_http_1_1_controllers_1_1_usuarios.html#a8aa0392530bfd7f41e86197d24deb673',1,'App::Http::Controllers::Usuarios::usuarioExiste()']]]
];
