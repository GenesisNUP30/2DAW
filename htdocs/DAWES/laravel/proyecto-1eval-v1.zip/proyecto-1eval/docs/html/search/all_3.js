var searchData=
[
  ['base_5furl_0',['BASE_URL',['../web_8php.html#ac2f7c46cdf071163a82cb95295eca57f',1,'web.php']]],
  ['bottom_1',['bottom',['../eliminar_8blade_8php.html#a9324057a236bf5a4cb4b02d83f2a5722',1,'bottom:&#160;eliminar.blade.php'],['../listarusuarios_8blade_8php.html#a9034efd9266ed643f35aa86e8ca32ac2',1,'bottom:&#160;listarusuarios.blade.php'],['../login_8blade_8php.html#a9034efd9266ed643f35aa86e8ca32ac2',1,'bottom:&#160;login.blade.php'],['../tareadetalle_8blade_8php.html#a9324057a236bf5a4cb4b02d83f2a5722',1,'bottom:&#160;tareadetalle.blade.php']]],
  ['btn_2',['btn',['../index_8blade_8php.html#a881ceca034d9d3cc804c36c0df391802',1,'btn:&#160;index.blade.php'],['../listarusuarios_8blade_8php.html#a81bc31be429c197f5a3613e23bf1e321',1,'btn:&#160;listarusuarios.blade.php']]]
];
