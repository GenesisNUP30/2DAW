var searchData=
[
  ['registraalta_0',['registraAlta',['../class_app_1_1_models_1_1_tareas.html#ac5b8326ec3b6e12b42b1900290b147f7',1,'App::Models::Tareas::registraAlta()'],['../class_app_1_1_http_1_1_controllers_1_1_tareas.html#ac5b8326ec3b6e12b42b1900290b147f7',1,'App::Http::Controllers::Tareas::registraAlta()']]],
  ['registrausuario_1',['registraUsuario',['../class_app_1_1_models_1_1_usuarios.html#ad556032cca4e54d4fa1add22ab977634',1,'App::Models::Usuarios::registraUsuario()'],['../class_app_1_1_http_1_1_controllers_1_1_usuarios.html#ad556032cca4e54d4fa1add22ab977634',1,'App::Http::Controllers::Usuarios::registraUsuario()']]],
  ['registroactual_2',['RegistroActual',['../class_app_1_1_models_1_1_d_b.html#a8c9707a442fdd06e64449ca9abeb663e',1,'App::Models::DB']]]
];
