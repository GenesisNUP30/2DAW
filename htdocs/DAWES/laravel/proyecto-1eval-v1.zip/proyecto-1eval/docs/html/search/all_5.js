var searchData=
[
  ['datos_0',['datos',['../eliminar_8blade_8php.html#a9a45f7a6bffc18e9945796b3752a4c37',1,'eliminar.blade.php']]],
  ['db_1',['DB',['../class_app_1_1_models_1_1_d_b.html',1,'App::Models']]],
  ['db_2ephp_2',['DB.php',['../_d_b_8php.html',1,'']]],
  ['dbconexion_2ephp_3',['DBConexion.php',['../_d_b_conexion_8php.html',1,'']]],
  ['decoration_4',['decoration',['../a_xC3_xB1adirusuario_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;añadirusuario.blade.php'],['../alta_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;alta.blade.php'],['../completar_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;completar.blade.php'],['../editarusuario_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;editarusuario.blade.php'],['../eliminar_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;eliminar.blade.php'],['../eliminarusuario_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;eliminarusuario.blade.php'],['../index_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;index.blade.php'],['../listarusuarios_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;listarusuarios.blade.php'],['../modificar_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;modificar.blade.php'],['../tareadetalle_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;tareadetalle.blade.php']]],
  ['detalle_5',['detalle',['../index_8blade_8php.html#a5fe660de1e45619908731b5b867bb023',1,'index.blade.php']]]
];
