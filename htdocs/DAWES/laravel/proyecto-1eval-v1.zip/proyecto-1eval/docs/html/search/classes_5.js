var searchData=
[
  ['inicioctrl_0',['InicioCtrl',['../class_app_1_1_http_1_1_controllers_1_1_inicio_ctrl.html',1,'App::Http::Controllers::InicioCtrl'],['../class_inicio_ctrl.html',1,'InicioCtrl']]]
];
