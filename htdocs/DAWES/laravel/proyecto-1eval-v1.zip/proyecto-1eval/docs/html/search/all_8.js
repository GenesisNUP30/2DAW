var searchData=
[
  ['gethoralogeada_0',['getHoraLogeada',['../class_app_1_1_models_1_1_sesion.html#ada9ea0b417e486f34414b865bacdb2f3',1,'App::Models::Sesion::getHoraLogeada()'],['../class_app_1_1_http_1_1_controllers_1_1_sesion.html#ada9ea0b417e486f34414b865bacdb2f3',1,'App::Http::Controllers::Sesion::getHoraLogeada()']]],
  ['getinstance_1',['getInstance',['../class_app_1_1_models_1_1_d_b.html#ad21ae5a79e7513545ddc5b0c56bcb9db',1,'App::Models::DB::getInstance()'],['../class_app_1_1_models_1_1_sesion.html#a5bb4be101384386b32f0f20dadd296f5',1,'App::Models::Sesion::getInstance()'],['../class_app_1_1_http_1_1_controllers_1_1_sesion.html#a5bb4be101384386b32f0f20dadd296f5',1,'App::Http::Controllers::Sesion::getInstance()']]],
  ['getrol_2',['getRol',['../class_app_1_1_models_1_1_sesion.html#a1f78a761cbcdd6b48ce57b75587f28ed',1,'App::Models::Sesion::getRol()'],['../class_app_1_1_http_1_1_controllers_1_1_sesion.html#a1f78a761cbcdd6b48ce57b75587f28ed',1,'App::Http::Controllers::Sesion::getRol()']]],
  ['getusuario_3',['getUsuario',['../class_app_1_1_models_1_1_sesion.html#a0adf25dec65e58e04ec2ea8f944ab21d',1,'App::Models::Sesion::getUsuario()'],['../class_app_1_1_http_1_1_controllers_1_1_sesion.html#a0adf25dec65e58e04ec2ea8f944ab21d',1,'App::Http::Controllers::Sesion::getUsuario()']]],
  ['group_4',['group',['../login_8blade_8php.html#a2497ed1038c286a4517b048108f1c1bd',1,'login.blade.php']]]
];
