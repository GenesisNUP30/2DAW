var searchData=
[
  ['user_0',['User',['../class_app_1_1_models_1_1_user.html',1,'App::Models']]],
  ['usuarios_1',['Usuarios',['../class_app_1_1_http_1_1_controllers_1_1_usuarios.html',1,'App::Http::Controllers::Usuarios'],['../class_app_1_1_models_1_1_usuarios.html',1,'App::Models::Usuarios']]]
];
