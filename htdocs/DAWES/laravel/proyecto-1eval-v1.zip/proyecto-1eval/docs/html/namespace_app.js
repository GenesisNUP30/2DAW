var namespace_app =
[
    [ "Http", null, [
      [ "Controllers", "namespace_app_1_1_http_1_1_controllers.html", "namespace_app_1_1_http_1_1_controllers" ]
    ] ],
    [ "Models", "namespace_app_1_1_models.html", "namespace_app_1_1_models" ]
];