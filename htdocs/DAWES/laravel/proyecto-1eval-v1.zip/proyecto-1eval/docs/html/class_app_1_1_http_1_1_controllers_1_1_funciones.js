var class_app_1_1_http_1_1_controllers_1_1_funciones =
[
    [ "cambiarFormatoFecha", "class_app_1_1_http_1_1_controllers_1_1_funciones.html#a375468f62a00efecf0edf5192e92ed7a", null ],
    [ "comprobarPassword", "class_app_1_1_http_1_1_controllers_1_1_funciones.html#af246c308a126dd8d4ad16c882a763e9c", null ],
    [ "formatearFechaHora", "class_app_1_1_http_1_1_controllers_1_1_funciones.html#a64f5883a0598b1e4c92a803fb046cbef", null ],
    [ "mostrarProvincias", "class_app_1_1_http_1_1_controllers_1_1_funciones.html#a16637a0a4badc319700a24ae70d26a93", null ],
    [ "telefonoValido", "class_app_1_1_http_1_1_controllers_1_1_funciones.html#a99b38c9e9971edaa3476f9a3f9bfc645", null ],
    [ "validarNif", "class_app_1_1_http_1_1_controllers_1_1_funciones.html#a08850cd7b923c29569f656b29963bed3", null ],
    [ "verErrores", "class_app_1_1_http_1_1_controllers_1_1_funciones.html#a1c10bf2bb45fdb103eabb7da68f82531", null ],
    [ "$errores", "class_app_1_1_http_1_1_controllers_1_1_funciones.html#a0e4625316e78f2744082e3d076e31b3c", null ],
    [ "$provincias", "class_app_1_1_http_1_1_controllers_1_1_funciones.html#a1d817d313e2d216ad1759ebce1990fa4", null ]
];