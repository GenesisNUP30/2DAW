var class_editar_usuario_ctrl =
[
    [ "actualizar", "class_editar_usuario_ctrl.html#aa6cac5dfed748498aa70e14e647c60b8", null ],
    [ "filtraDatos", "class_editar_usuario_ctrl.html#a7dc24acc356a556d817f5af6fffe1731", null ]
];