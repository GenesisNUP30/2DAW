var _alta_ctrl_8php =
[
    [ "App::Http::Controllers::AltaCtrl", "class_app_1_1_http_1_1_controllers_1_1_alta_ctrl.html", "class_app_1_1_http_1_1_controllers_1_1_alta_ctrl" ],
    [ "App::Http::Controllers::Tareas", "class_app_1_1_http_1_1_controllers_1_1_tareas.html", "class_app_1_1_http_1_1_controllers_1_1_tareas" ]
];