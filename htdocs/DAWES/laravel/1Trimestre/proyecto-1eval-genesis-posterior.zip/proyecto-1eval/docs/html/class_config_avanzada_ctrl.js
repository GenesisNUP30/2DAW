var class_config_avanzada_ctrl =
[
    [ "filtraDatos", "class_config_avanzada_ctrl.html#a113435fde370ae1f1468b6c17cb89643", null ],
    [ "guardar", "class_config_avanzada_ctrl.html#abe506a88244eaea0ed932d94fa1cdcab", null ],
    [ "mostrar", "class_config_avanzada_ctrl.html#aaad9cb64f80eb6efd5e70abe4fd6a23b", null ]
];