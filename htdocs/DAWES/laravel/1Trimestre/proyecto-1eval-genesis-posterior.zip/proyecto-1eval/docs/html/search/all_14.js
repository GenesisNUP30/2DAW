var searchData=
[
  ['validarcodigopostalprovincia_0',['validarCodigoPostalProvincia',['../class_app_1_1_models_1_1_funciones.html#ad6f1623a66088c7d4396c49f57071250',1,'App::Models::Funciones::validarCodigoPostalProvincia()'],['../class_app_1_1_http_1_1_controllers_1_1_funciones.html#a92ca55820503b41007bebc1f4355db74',1,'App::Http::Controllers::Funciones::validarCodigoPostalProvincia()']]],
  ['validarlogin_1',['validarLogin',['../class_app_1_1_models_1_1_sesion.html#a149770ec4f2e520051635a5b39d4da20',1,'App::Models::Sesion::validarLogin()'],['../class_app_1_1_http_1_1_controllers_1_1_sesion.html#a149770ec4f2e520051635a5b39d4da20',1,'App::Http::Controllers::Sesion::validarLogin()']]],
  ['validarnif_2',['validarNif',['../class_app_1_1_models_1_1_funciones.html#a3848aef567bb27a3d9f770c31fe90e80',1,'App::Models::Funciones::validarNif()'],['../class_app_1_1_http_1_1_controllers_1_1_funciones.html#a08850cd7b923c29569f656b29963bed3',1,'App::Http::Controllers::Funciones::validarNif()']]],
  ['vererrores_3',['verErrores',['../class_app_1_1_models_1_1_funciones.html#a538d8998a1cb621aea4a0424d7037eae',1,'App::Models::Funciones::verErrores()'],['../class_app_1_1_http_1_1_controllers_1_1_funciones.html#a1c10bf2bb45fdb103eabb7da68f82531',1,'App::Http::Controllers::Funciones::verErrores()']]],
  ['vertarea_4',['verTarea',['../class_app_1_1_http_1_1_controllers_1_1_inicio_ctrl.html#ae187e03505a2fdab2f893fc53812ff6c',1,'App::Http::Controllers::InicioCtrl::verTarea()'],['../class_inicio_ctrl.html#af6b3024af40df40840e38e4770cb16bb',1,'InicioCtrl::verTarea()']]],
  ['verusuariosctrl_5',['VerUsuariosCtrl',['../class_app_1_1_http_1_1_controllers_1_1_ver_usuarios_ctrl.html',1,'App::Http::Controllers::VerUsuariosCtrl'],['../class_ver_usuarios_ctrl.html',1,'VerUsuariosCtrl']]],
  ['verusuariosctrl_2ephp_6',['VerUsuariosCtrl.php',['../_ver_usuarios_ctrl_8php.html',1,'']]],
  ['volver_7',['volver',['../tareadetalle_8blade_8php.html#ac7cce97763ef61ff53c3c169850220e4',1,'tareadetalle.blade.php']]]
];
