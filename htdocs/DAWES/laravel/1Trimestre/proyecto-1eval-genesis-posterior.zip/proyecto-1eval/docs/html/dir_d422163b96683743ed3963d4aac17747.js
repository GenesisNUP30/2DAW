var dir_d422163b96683743ed3963d4aac17747 =
[
    [ "Http", "dir_0c4ee04d587063ecca91a7f35642b9f3.html", "dir_0c4ee04d587063ecca91a7f35642b9f3" ],
    [ "Models", "dir_fc6199fba97859a095e1d9a5aa5fae23.html", "dir_fc6199fba97859a095e1d9a5aa5fae23" ]
];