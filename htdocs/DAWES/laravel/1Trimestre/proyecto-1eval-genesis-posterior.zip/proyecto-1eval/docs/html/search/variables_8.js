var searchData=
[
  ['group_0',['group',['../login_8blade_8php.html#a2497ed1038c286a4517b048108f1c1bd',1,'login.blade.php']]]
];
