var searchData=
[
  ['yield_0',['yield',['../plantilla01_8blade_8php.html#aa94b7ff24a66c590ae37f6f3f3abe8f9',1,'yield(&apos;titulo&apos;)&lt;/title &gt;&lt;!-- Estilos generales - -&gt;&lt; style &gt; body:&#160;plantilla01.blade.php'],['../plantilla01_8blade_8php.html#a9ed4506148458c53a35ff2badbae0922',1,'yield(&apos;estilos&apos;)&lt;/head &gt;&lt; body class:&#160;plantilla01.blade.php']]]
];
