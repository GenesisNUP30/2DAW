var _config_avanzada_8php =
[
    [ "App::Models::ConfigAvanzada", "class_app_1_1_models_1_1_config_avanzada.html", "class_app_1_1_models_1_1_config_avanzada" ]
];