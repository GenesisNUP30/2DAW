var searchData=
[
  ['app_0',['App',['../namespace_app.html',1,'']]],
  ['app_3a_3ahttp_3a_3acontrollers_1',['Controllers',['../namespace_app_1_1_http_1_1_controllers.html',1,'App::Http']]],
  ['app_3a_3amodels_2',['Models',['../namespace_app_1_1_models.html',1,'App']]]
];
