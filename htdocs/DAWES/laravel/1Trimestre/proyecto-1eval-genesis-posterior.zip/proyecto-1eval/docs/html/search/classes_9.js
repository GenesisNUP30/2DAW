var searchData=
[
  ['tareas_0',['Tareas',['../class_app_1_1_http_1_1_controllers_1_1_tareas.html',1,'App::Http::Controllers::Tareas'],['../class_app_1_1_models_1_1_tareas.html',1,'App::Models::Tareas']]]
];
