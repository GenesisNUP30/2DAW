var searchData=
[
  ['telefonovalido_0',['telefonoValido',['../class_app_1_1_models_1_1_funciones.html#affaf620907ad5530cabac385b82ba542',1,'App::Models::Funciones::telefonoValido()'],['../class_app_1_1_http_1_1_controllers_1_1_funciones.html#a99b38c9e9971edaa3476f9a3f9bfc645',1,'App::Http::Controllers::Funciones::telefonoValido()']]]
];
