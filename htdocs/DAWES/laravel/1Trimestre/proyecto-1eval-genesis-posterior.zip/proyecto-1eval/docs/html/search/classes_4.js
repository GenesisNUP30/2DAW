var searchData=
[
  ['funciones_0',['Funciones',['../class_app_1_1_http_1_1_controllers_1_1_funciones.html',1,'App::Http::Controllers::Funciones'],['../class_app_1_1_models_1_1_funciones.html',1,'App::Models::Funciones']]]
];
