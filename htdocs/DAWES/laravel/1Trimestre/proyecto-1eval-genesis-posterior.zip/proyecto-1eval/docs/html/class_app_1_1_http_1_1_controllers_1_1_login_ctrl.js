var class_app_1_1_http_1_1_controllers_1_1_login_ctrl =
[
    [ "login", "class_app_1_1_http_1_1_controllers_1_1_login_ctrl.html#af442005084992372b23b9397a1fbd8cd", null ],
    [ "logout", "class_app_1_1_http_1_1_controllers_1_1_login_ctrl.html#a11b9f497b93fb498aa3686805bf7fda7", null ]
];