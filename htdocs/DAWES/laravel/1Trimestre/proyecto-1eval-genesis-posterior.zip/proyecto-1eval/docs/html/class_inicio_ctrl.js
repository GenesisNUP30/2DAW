var class_inicio_ctrl =
[
    [ "descargarFichero", "class_inicio_ctrl.html#a7ee1bd75e94016084d123e263efbfe12", null ],
    [ "index", "class_inicio_ctrl.html#a3893c71a0ffefcd47a327907f7507b6b", null ],
    [ "verTarea", "class_inicio_ctrl.html#af6b3024af40df40840e38e4770cb16bb", null ]
];