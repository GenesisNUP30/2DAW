var searchData=
[
  ['descargarfichero_0',['descargarFichero',['../class_app_1_1_http_1_1_controllers_1_1_inicio_ctrl.html#ac22d4740e952785398752360df0115d5',1,'App::Http::Controllers::InicioCtrl::descargarFichero()'],['../class_inicio_ctrl.html#a7ee1bd75e94016084d123e263efbfe12',1,'InicioCtrl::descargarFichero()']]]
];
