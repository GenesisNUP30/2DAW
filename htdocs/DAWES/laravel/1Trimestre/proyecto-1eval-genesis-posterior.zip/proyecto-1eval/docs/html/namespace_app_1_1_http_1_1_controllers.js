var namespace_app_1_1_http_1_1_controllers =
[
    [ "AñadirUsuarioCtrl", "class_app_1_1_http_1_1_controllers_1_1_a_xC3_xB1adir_usuario_ctrl.html", "class_app_1_1_http_1_1_controllers_1_1_a_xC3_xB1adir_usuario_ctrl" ],
    [ "AltaCtrl", "class_app_1_1_http_1_1_controllers_1_1_alta_ctrl.html", "class_app_1_1_http_1_1_controllers_1_1_alta_ctrl" ],
    [ "CompletarCtrl", "class_app_1_1_http_1_1_controllers_1_1_completar_ctrl.html", "class_app_1_1_http_1_1_controllers_1_1_completar_ctrl" ],
    [ "ConfigAvanzadaCtrl", "class_app_1_1_http_1_1_controllers_1_1_config_avanzada_ctrl.html", "class_app_1_1_http_1_1_controllers_1_1_config_avanzada_ctrl" ],
    [ "Controller", "class_app_1_1_http_1_1_controllers_1_1_controller.html", null ],
    [ "EditarUsuarioCtrl", "class_app_1_1_http_1_1_controllers_1_1_editar_usuario_ctrl.html", "class_app_1_1_http_1_1_controllers_1_1_editar_usuario_ctrl" ],
    [ "EliminarCtrl", "class_app_1_1_http_1_1_controllers_1_1_eliminar_ctrl.html", "class_app_1_1_http_1_1_controllers_1_1_eliminar_ctrl" ],
    [ "EliminarUsuarioCtrl", "class_app_1_1_http_1_1_controllers_1_1_eliminar_usuario_ctrl.html", "class_app_1_1_http_1_1_controllers_1_1_eliminar_usuario_ctrl" ],
    [ "InicioCtrl", "class_app_1_1_http_1_1_controllers_1_1_inicio_ctrl.html", "class_app_1_1_http_1_1_controllers_1_1_inicio_ctrl" ],
    [ "LoginCtrl", "class_app_1_1_http_1_1_controllers_1_1_login_ctrl.html", "class_app_1_1_http_1_1_controllers_1_1_login_ctrl" ],
    [ "ModificarCtrl", "class_app_1_1_http_1_1_controllers_1_1_modificar_ctrl.html", "class_app_1_1_http_1_1_controllers_1_1_modificar_ctrl" ],
    [ "VerUsuariosCtrl", "class_app_1_1_http_1_1_controllers_1_1_ver_usuarios_ctrl.html", null ],
    [ "Usuarios", "class_app_1_1_http_1_1_controllers_1_1_usuarios.html", "class_app_1_1_http_1_1_controllers_1_1_usuarios" ],
    [ "Sesion", "class_app_1_1_http_1_1_controllers_1_1_sesion.html", "class_app_1_1_http_1_1_controllers_1_1_sesion" ],
    [ "Funciones", "class_app_1_1_http_1_1_controllers_1_1_funciones.html", "class_app_1_1_http_1_1_controllers_1_1_funciones" ],
    [ "Tareas", "class_app_1_1_http_1_1_controllers_1_1_tareas.html", "class_app_1_1_http_1_1_controllers_1_1_tareas" ],
    [ "ConfigAvanzada", "class_app_1_1_http_1_1_controllers_1_1_config_avanzada.html", "class_app_1_1_http_1_1_controllers_1_1_config_avanzada" ]
];