var namespace_app_1_1_models =
[
    [ "ConfigAvanzada", "class_app_1_1_models_1_1_config_avanzada.html", "class_app_1_1_models_1_1_config_avanzada" ],
    [ "DB", "class_app_1_1_models_1_1_d_b.html", "class_app_1_1_models_1_1_d_b" ],
    [ "Funciones", "class_app_1_1_models_1_1_funciones.html", "class_app_1_1_models_1_1_funciones" ],
    [ "Sesion", "class_app_1_1_models_1_1_sesion.html", "class_app_1_1_models_1_1_sesion" ],
    [ "Tareas", "class_app_1_1_models_1_1_tareas.html", "class_app_1_1_models_1_1_tareas" ],
    [ "User", "class_app_1_1_models_1_1_user.html", "class_app_1_1_models_1_1_user" ],
    [ "Usuarios", "class_app_1_1_models_1_1_usuarios.html", "class_app_1_1_models_1_1_usuarios" ]
];