var _d_b_conexion_8php =
[
    [ "return", "_d_b_conexion_8php.html#a8ed1a9e54f0e3f7673c21c4a2a97919e", null ]
];