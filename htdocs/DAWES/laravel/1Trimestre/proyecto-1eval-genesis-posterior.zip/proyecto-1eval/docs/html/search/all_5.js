var searchData=
[
  ['danger_0',['danger',['../plantilla01_8blade_8php.html#ab92e2cc6eb4737d0fe1a8f4b6583483c',1,'plantilla01.blade.php']]],
  ['datos_1',['datos',['../eliminar_8blade_8php.html#ae32fb26bc6fd6c3f5d8173121f752abe',1,'datos:&#160;eliminar.blade.php'],['../plantilla01_8blade_8php.html#ae32fb26bc6fd6c3f5d8173121f752abe',1,'datos:&#160;plantilla01.blade.php']]],
  ['db_2',['DB',['../class_app_1_1_models_1_1_d_b.html',1,'App::Models']]],
  ['db_2ephp_3',['DB.php',['../_d_b_8php.html',1,'']]],
  ['dbconexion_2ephp_4',['DBConexion.php',['../_d_b_conexion_8php.html',1,'']]],
  ['decoration_5',['decoration',['../a_xC3_xB1adirusuario_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;añadirusuario.blade.php'],['../alta_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;alta.blade.php'],['../completar_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;completar.blade.php'],['../editarusuario_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;editarusuario.blade.php'],['../eliminar_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;eliminar.blade.php'],['../eliminarusuario_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;eliminarusuario.blade.php'],['../index_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;index.blade.php'],['../listarusuarios_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;listarusuarios.blade.php'],['../modificar_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;modificar.blade.php'],['../tareadetalle_8blade_8php.html#ad1ba8052b5e15f7bd3093dcb839f840b',1,'decoration:&#160;tareadetalle.blade.php']]],
  ['descargarfichero_6',['descargarFichero',['../class_app_1_1_http_1_1_controllers_1_1_inicio_ctrl.html#ac22d4740e952785398752360df0115d5',1,'App::Http::Controllers::InicioCtrl::descargarFichero()'],['../class_inicio_ctrl.html#a7ee1bd75e94016084d123e263efbfe12',1,'InicioCtrl::descargarFichero()']]],
  ['detalle_7',['detalle',['../index_8blade_8php.html#a5fe660de1e45619908731b5b867bb023',1,'index.blade.php']]],
  ['direction_8',['direction',['../plantilla01_8blade_8php.html#a9535506cd21c110d81f7fa46caa7c58b',1,'plantilla01.blade.php']]],
  ['div_9',['div',['../plantilla01_8blade_8php.html#afb77bb29e2f83790040076697d78f422',1,'plantilla01.blade.php']]]
];
