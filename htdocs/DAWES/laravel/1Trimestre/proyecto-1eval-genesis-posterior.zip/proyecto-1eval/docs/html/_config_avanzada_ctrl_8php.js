var _config_avanzada_ctrl_8php =
[
    [ "App::Http::Controllers::ConfigAvanzadaCtrl", "class_app_1_1_http_1_1_controllers_1_1_config_avanzada_ctrl.html", "class_app_1_1_http_1_1_controllers_1_1_config_avanzada_ctrl" ]
];