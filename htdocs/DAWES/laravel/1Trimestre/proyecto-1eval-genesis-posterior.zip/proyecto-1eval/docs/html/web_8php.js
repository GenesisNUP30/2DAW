var web_8php =
[
    [ "AltaCtrl", "class_alta_ctrl.html", "class_alta_ctrl" ],
    [ "AñadirUsuarioCtrl", "class_a_xC3_xB1adir_usuario_ctrl.html", "class_a_xC3_xB1adir_usuario_ctrl" ],
    [ "CompletarCtrl", "class_completar_ctrl.html", "class_completar_ctrl" ],
    [ "EliminarCtrl", "class_eliminar_ctrl.html", "class_eliminar_ctrl" ],
    [ "InicioCtrl", "class_inicio_ctrl.html", "class_inicio_ctrl" ],
    [ "ModificarCtrl", "class_modificar_ctrl.html", "class_modificar_ctrl" ],
    [ "LoginCtrl", "class_login_ctrl.html", "class_login_ctrl" ],
    [ "VerUsuariosCtrl", "class_ver_usuarios_ctrl.html", null ],
    [ "EditarUsuarioCtrl", "class_editar_usuario_ctrl.html", "class_editar_usuario_ctrl" ],
    [ "EliminarUsuarioCtrl", "class_eliminar_usuario_ctrl.html", "class_eliminar_usuario_ctrl" ],
    [ "ConfigAvanzadaCtrl", "class_config_avanzada_ctrl.html", "class_config_avanzada_ctrl" ],
    [ "miredirect", "web_8php.html#a076207b7d94d13a2d6df72dd75c2de69", null ],
    [ "BASE_URL", "web_8php.html#ac2f7c46cdf071163a82cb95295eca57f", null ],
    [ "miurl", "web_8php.html#a64bc0e98bff60531d07f2220330aeaf9", null ]
];