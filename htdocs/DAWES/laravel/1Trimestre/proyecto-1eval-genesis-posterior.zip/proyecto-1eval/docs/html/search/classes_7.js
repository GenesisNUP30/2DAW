var searchData=
[
  ['modificarctrl_0',['ModificarCtrl',['../class_app_1_1_http_1_1_controllers_1_1_modificar_ctrl.html',1,'App::Http::Controllers::ModificarCtrl'],['../class_modificar_ctrl.html',1,'ModificarCtrl']]]
];
