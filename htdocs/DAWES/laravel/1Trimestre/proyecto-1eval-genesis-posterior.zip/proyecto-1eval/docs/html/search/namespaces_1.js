var searchData=
[
  ['config_0',['Config',['../namespace_config.html',1,'']]]
];
