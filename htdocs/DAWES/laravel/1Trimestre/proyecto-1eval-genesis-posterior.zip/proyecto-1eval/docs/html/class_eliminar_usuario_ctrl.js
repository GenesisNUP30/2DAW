var class_eliminar_usuario_ctrl =
[
    [ "confirmar", "class_eliminar_usuario_ctrl.html#afe42ffb24a1add24e60c6b85de427435", null ],
    [ "eliminar", "class_eliminar_usuario_ctrl.html#ac0e49a0e11042e692d5ba81cd2e06312", null ]
];