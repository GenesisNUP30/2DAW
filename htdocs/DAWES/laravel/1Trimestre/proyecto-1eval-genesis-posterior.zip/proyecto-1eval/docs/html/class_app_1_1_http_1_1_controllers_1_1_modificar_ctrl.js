var class_app_1_1_http_1_1_controllers_1_1_modificar_ctrl =
[
    [ "actualizar", "class_app_1_1_http_1_1_controllers_1_1_modificar_ctrl.html#aef65f1e3a572e9ebad65d2c155644bb6", null ],
    [ "filtraDatos", "class_app_1_1_http_1_1_controllers_1_1_modificar_ctrl.html#a10f698e6eb7c4801ec8c3f1879938eb7", null ],
    [ "mostrarFormulario", "class_app_1_1_http_1_1_controllers_1_1_modificar_ctrl.html#a435e75e0551de24335f0b0b1efae6676", null ]
];