var class_app_1_1_models_1_1_config_avanzada =
[
    [ "__clone", "class_app_1_1_models_1_1_config_avanzada.html#a713be2eadc2f076d03399fc77e4c3fba", null ],
    [ "__construct", "class_app_1_1_models_1_1_config_avanzada.html#a665bc57766d53b74d8ba9d020523af6f", null ],
    [ "getInstance", "class_app_1_1_models_1_1_config_avanzada.html#ac2b27cb195e9e8c6b8f2d48ec721e98e", null ],
    [ "getTiempoSesionMinutos", "class_app_1_1_models_1_1_config_avanzada.html#a4b5ace06cafbd4bfc7970dd618e84f8e", null ],
    [ "guardar", "class_app_1_1_models_1_1_config_avanzada.html#a31394451571dd2bf2ad9a5ad25305434", null ],
    [ "setMinutosSegundos", "class_app_1_1_models_1_1_config_avanzada.html#a6063d394af52b65d9bfc1d0e8d1eeca7", null ],
    [ "$bd", "class_app_1_1_models_1_1_config_avanzada.html#a2a7e2148a347e3837c8c900072156047", null ],
    [ "$instance", "class_app_1_1_models_1_1_config_avanzada.html#aa16637d4849aae597f0c83989a479295", null ],
    [ "$items_por_pagina", "class_app_1_1_models_1_1_config_avanzada.html#a829e944bf684a29f1d4a910890c4fa49", null ],
    [ "$poblacion_defecto", "class_app_1_1_models_1_1_config_avanzada.html#ae65276a39c3dcc290c3fff85c2ed4d1e", null ],
    [ "$provincia_defecto", "class_app_1_1_models_1_1_config_avanzada.html#a8ec63245082b4ab5e8e2a8a0e35fe4ea", null ],
    [ "$tema", "class_app_1_1_models_1_1_config_avanzada.html#abc48907028678f00ac9eba74ee867dd6", null ],
    [ "$tiempo_sesion", "class_app_1_1_models_1_1_config_avanzada.html#afc54964f8e0c7b0548e29e0ff64dadd8", null ]
];