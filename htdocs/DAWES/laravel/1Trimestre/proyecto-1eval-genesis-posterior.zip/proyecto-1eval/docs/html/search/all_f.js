var searchData=
[
  ['query_0',['query',['../class_app_1_1_models_1_1_d_b.html#a2facf61f010643b18f2e1257f41fa2b1',1,'App::Models::DB']]]
];
