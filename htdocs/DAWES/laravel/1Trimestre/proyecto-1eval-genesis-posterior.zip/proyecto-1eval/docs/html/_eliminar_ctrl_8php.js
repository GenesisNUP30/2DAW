var _eliminar_ctrl_8php =
[
    [ "App::Http::Controllers::EliminarCtrl", "class_app_1_1_http_1_1_controllers_1_1_eliminar_ctrl.html", "class_app_1_1_http_1_1_controllers_1_1_eliminar_ctrl" ]
];