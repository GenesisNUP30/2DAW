var class_app_1_1_models_1_1_sesion =
[
    [ "__clone", "class_app_1_1_models_1_1_sesion.html#af1c45a10ec901e69282fa3a5ded83af4", null ],
    [ "__construct", "class_app_1_1_models_1_1_sesion.html#a4014f3a69bb77128e81759334cc7e88e", null ],
    [ "borrarCookiesRecordarme", "class_app_1_1_models_1_1_sesion.html#a0046bc3b6484cab838ef2833ee314156", null ],
    [ "crearTokenRecordarme", "class_app_1_1_models_1_1_sesion.html#acb010eb3705d82f1c4eb8927ef24ab80", null ],
    [ "getHoraLogeada", "class_app_1_1_models_1_1_sesion.html#ada9ea0b417e486f34414b865bacdb2f3", null ],
    [ "getInstance", "class_app_1_1_models_1_1_sesion.html#a5bb4be101384386b32f0f20dadd296f5", null ],
    [ "getRol", "class_app_1_1_models_1_1_sesion.html#a1f78a761cbcdd6b48ce57b75587f28ed", null ],
    [ "getUsuario", "class_app_1_1_models_1_1_sesion.html#a0adf25dec65e58e04ec2ea8f944ab21d", null ],
    [ "isLogged", "class_app_1_1_models_1_1_sesion.html#a02fce64b8bbaaa308ba237f68c7a5501", null ],
    [ "loginDesdeCookie", "class_app_1_1_models_1_1_sesion.html#aec7099248845d6b1a142bd116a33a91e", null ],
    [ "logout", "class_app_1_1_models_1_1_sesion.html#aa2b384fd894dac4d00594d08cb7d275e", null ],
    [ "onlyAdministrador", "class_app_1_1_models_1_1_sesion.html#a0cdd6be11b68798da7d4650311282fe7", null ],
    [ "onlyLogged", "class_app_1_1_models_1_1_sesion.html#a7353ff1d629512e4f6c28a3983589182", null ],
    [ "onlyOperario", "class_app_1_1_models_1_1_sesion.html#ad74d396f3f1d0bf04ba7c07d507c9870", null ],
    [ "validarLogin", "class_app_1_1_models_1_1_sesion.html#a149770ec4f2e520051635a5b39d4da20", null ],
    [ "$instance", "class_app_1_1_models_1_1_sesion.html#a6adbc49685dd678d4da3c411a074eb7e", null ]
];