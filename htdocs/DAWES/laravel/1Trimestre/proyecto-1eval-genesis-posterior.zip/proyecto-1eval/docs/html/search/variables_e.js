var searchData=
[
  ['p_0',['p',['../eliminar_8blade_8php.html#ab5bf0558ccdd6a46caf16f41f7ae478f',1,'p:&#160;eliminar.blade.php'],['../plantilla01_8blade_8php.html#ab5bf0558ccdd6a46caf16f41f7ae478f',1,'p:&#160;plantilla01.blade.php']]],
  ['paginacion_1',['paginacion',['../index_8blade_8php.html#a699bbea62afd3aac6a0e5e172ddca142',1,'index.blade.php']]]
];
