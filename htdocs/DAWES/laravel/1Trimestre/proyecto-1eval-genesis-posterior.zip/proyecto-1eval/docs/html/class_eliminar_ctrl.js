var class_eliminar_ctrl =
[
    [ "confirmar", "class_eliminar_ctrl.html#a83e5237bef2ca305ab468d6e74ee2305", null ],
    [ "eliminar", "class_eliminar_ctrl.html#ae24b540457c26e22fe62e5b942d69555", null ]
];