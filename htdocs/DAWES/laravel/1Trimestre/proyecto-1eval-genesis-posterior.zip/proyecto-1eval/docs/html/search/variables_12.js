var searchData=
[
  ['volver_0',['volver',['../tareadetalle_8blade_8php.html#ac7cce97763ef61ff53c3c169850220e4',1,'tareadetalle.blade.php']]]
];
