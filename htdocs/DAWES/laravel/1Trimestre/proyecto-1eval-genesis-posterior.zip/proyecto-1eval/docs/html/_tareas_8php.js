var _tareas_8php =
[
    [ "App::Models::Tareas", "class_app_1_1_models_1_1_tareas.html", "class_app_1_1_models_1_1_tareas" ]
];