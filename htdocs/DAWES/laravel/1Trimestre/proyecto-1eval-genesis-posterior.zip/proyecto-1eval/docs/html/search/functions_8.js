var searchData=
[
  ['index_0',['index',['../class_app_1_1_http_1_1_controllers_1_1_inicio_ctrl.html#a3893c71a0ffefcd47a327907f7507b6b',1,'App::Http::Controllers::InicioCtrl::index()'],['../class_inicio_ctrl.html#a3893c71a0ffefcd47a327907f7507b6b',1,'InicioCtrl::index()']]],
  ['islogged_1',['isLogged',['../class_app_1_1_models_1_1_sesion.html#a02fce64b8bbaaa308ba237f68c7a5501',1,'App::Models::Sesion::isLogged()'],['../class_app_1_1_http_1_1_controllers_1_1_sesion.html#a02fce64b8bbaaa308ba237f68c7a5501',1,'App::Http::Controllers::Sesion::isLogged()']]]
];
