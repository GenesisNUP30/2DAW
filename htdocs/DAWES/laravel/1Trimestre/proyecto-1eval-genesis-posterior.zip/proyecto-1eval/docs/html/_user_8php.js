var _user_8php =
[
    [ "App::Models::User", "class_app_1_1_models_1_1_user.html", "class_app_1_1_models_1_1_user" ]
];