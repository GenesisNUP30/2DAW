var searchData=
[
  ['validarlogin_0',['validarLogin',['../class_app_1_1_models_1_1_sesion.html#a149770ec4f2e520051635a5b39d4da20',1,'App::Models::Sesion::validarLogin()'],['../class_app_1_1_http_1_1_controllers_1_1_sesion.html#a149770ec4f2e520051635a5b39d4da20',1,'App::Http::Controllers::Sesion::validarLogin()']]],
  ['validarnif_1',['validarNif',['../class_app_1_1_models_1_1_funciones.html#a3848aef567bb27a3d9f770c31fe90e80',1,'App::Models::Funciones::validarNif()'],['../class_app_1_1_http_1_1_controllers_1_1_funciones.html#a08850cd7b923c29569f656b29963bed3',1,'App::Http::Controllers::Funciones::validarNif()']]],
  ['vererrores_2',['verErrores',['../class_app_1_1_models_1_1_funciones.html#a538d8998a1cb621aea4a0424d7037eae',1,'App::Models::Funciones::verErrores()'],['../class_app_1_1_http_1_1_controllers_1_1_funciones.html#a1c10bf2bb45fdb103eabb7da68f82531',1,'App::Http::Controllers::Funciones::verErrores()']]],
  ['vertarea_3',['verTarea',['../class_app_1_1_http_1_1_controllers_1_1_inicio_ctrl.html#ae187e03505a2fdab2f893fc53812ff6c',1,'App::Http::Controllers::InicioCtrl::verTarea()'],['../class_inicio_ctrl.html#af6b3024af40df40840e38e4770cb16bb',1,'InicioCtrl::verTarea()']]],
  ['verusuariosctrl_4',['VerUsuariosCtrl',['../class_app_1_1_http_1_1_controllers_1_1_ver_usuarios_ctrl.html',1,'App::Http::Controllers::VerUsuariosCtrl'],['../class_ver_usuarios_ctrl.html',1,'VerUsuariosCtrl']]],
  ['verusuariosctrl_2ephp_5',['VerUsuariosCtrl.php',['../_ver_usuarios_ctrl_8php.html',1,'']]],
  ['volver_6',['volver',['../tareadetalle_8blade_8php.html#abb04f27d0e3e84d602d639029cf1d469',1,'tareadetalle.blade.php']]]
];
