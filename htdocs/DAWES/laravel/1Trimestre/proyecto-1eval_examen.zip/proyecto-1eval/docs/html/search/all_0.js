var searchData=
[
  ['_24_5finstance_0',['$_instance',['../class_app_1_1_models_1_1_d_b.html#aa921105840c6708a8c14039e507445f3',1,'App::Models::DB']]],
  ['_24base_5fdatos_1',['$base_datos',['../class_app_1_1_models_1_1_d_b.html#a4c247ae621d20a548c944e10d36e8ac0',1,'App::Models::DB']]],
  ['_24bd_2',['$bd',['../class_app_1_1_models_1_1_tareas.html#a0b24fec2d479d380e103a24627ff0592',1,'App::Models::Tareas::$bd'],['../class_app_1_1_models_1_1_usuarios.html#ad08bbcfaa2673a20746d59745385d890',1,'App::Models::Usuarios::$bd'],['../class_app_1_1_http_1_1_controllers_1_1_usuarios.html#ad08bbcfaa2673a20746d59745385d890',1,'App::Http::Controllers::Usuarios::$bd'],['../class_app_1_1_http_1_1_controllers_1_1_tareas.html#a0b24fec2d479d380e103a24627ff0592',1,'App::Http::Controllers::Tareas::$bd']]],
  ['_24errores_3',['$errores',['../class_app_1_1_models_1_1_funciones.html#a0e4625316e78f2744082e3d076e31b3c',1,'App::Models::Funciones::$errores'],['../class_app_1_1_http_1_1_controllers_1_1_funciones.html#a0e4625316e78f2744082e3d076e31b3c',1,'App::Http::Controllers::Funciones::$errores']]],
  ['_24fillable_4',['$fillable',['../class_app_1_1_models_1_1_user.html#a1c460dfee2ba912e187f5475dc54fac3',1,'App::Models::User']]],
  ['_24hidden_5',['$hidden',['../class_app_1_1_models_1_1_user.html#ab0c168b8631888e590af403cd66418f8',1,'App::Models::User']]],
  ['_24instance_6',['$instance',['../class_app_1_1_models_1_1_sesion.html#a6adbc49685dd678d4da3c411a074eb7e',1,'App::Models::Sesion::$instance'],['../class_app_1_1_http_1_1_controllers_1_1_sesion.html#a6adbc49685dd678d4da3c411a074eb7e',1,'App::Http::Controllers::Sesion::$instance']]],
  ['_24link_7',['$link',['../class_app_1_1_models_1_1_d_b.html#af9c7d7b0f6b3db45327b54d27455dd53',1,'App::Models::DB']]],
  ['_24provincias_8',['$provincias',['../class_app_1_1_models_1_1_funciones.html#a1d817d313e2d216ad1759ebce1990fa4',1,'App::Models::Funciones::$provincias'],['../class_app_1_1_http_1_1_controllers_1_1_funciones.html#a1d817d313e2d216ad1759ebce1990fa4',1,'App::Http::Controllers::Funciones::$provincias']]],
  ['_24regactual_9',['$regActual',['../class_app_1_1_models_1_1_d_b.html#aaecbeda3ccf3aa04c2942c209f9858b4',1,'App::Models::DB']]],
  ['_24result_10',['$result',['../class_app_1_1_models_1_1_d_b.html#a6352dd828274faf1d2b6990715e2d252',1,'App::Models::DB']]]
];
