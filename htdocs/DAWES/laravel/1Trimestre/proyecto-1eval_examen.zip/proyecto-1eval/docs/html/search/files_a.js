var searchData=
[
  ['tareadetalle_2eblade_2ephp_0',['tareadetalle.blade.php',['../tareadetalle_8blade_8php.html',1,'']]],
  ['tareas_2ephp_1',['Tareas.php',['../_tareas_8php.html',1,'']]]
];
