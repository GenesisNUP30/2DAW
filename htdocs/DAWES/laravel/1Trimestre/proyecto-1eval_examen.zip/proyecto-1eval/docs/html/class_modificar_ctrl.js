var class_modificar_ctrl =
[
    [ "actualizar", "class_modificar_ctrl.html#aecaa968cac624e45ce02a3f83b120ae4", null ],
    [ "filtraDatos", "class_modificar_ctrl.html#a10f698e6eb7c4801ec8c3f1879938eb7", null ],
    [ "mostrarFormulario", "class_modificar_ctrl.html#ab0047f78a4e15e8739783523c8db6c1d", null ]
];