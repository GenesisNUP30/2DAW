var searchData=
[
  ['db_0',['DB',['../class_app_1_1_models_1_1_d_b.html',1,'App::Models']]]
];
