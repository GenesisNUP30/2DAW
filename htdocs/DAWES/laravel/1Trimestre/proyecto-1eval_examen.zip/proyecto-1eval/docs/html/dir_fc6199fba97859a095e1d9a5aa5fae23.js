var dir_fc6199fba97859a095e1d9a5aa5fae23 =
[
    [ "DB.php", "_d_b_8php.html", "_d_b_8php" ],
    [ "DBConexion.php", "_d_b_conexion_8php.html", "_d_b_conexion_8php" ],
    [ "Funciones.php", "_funciones_8php.html", "_funciones_8php" ],
    [ "Sesion.php", "_sesion_8php.html", "_sesion_8php" ],
    [ "Tareas.php", "_tareas_8php.html", "_tareas_8php" ],
    [ "User.php", "_user_8php.html", "_user_8php" ],
    [ "Usuarios.php", "_usuarios_8php.html", "_usuarios_8php" ]
];