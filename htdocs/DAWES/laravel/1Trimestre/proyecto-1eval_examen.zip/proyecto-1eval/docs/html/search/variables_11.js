var searchData=
[
  ['volver_0',['volver',['../tareadetalle_8blade_8php.html#abb04f27d0e3e84d602d639029cf1d469',1,'tareadetalle.blade.php']]]
];
