var class_app_1_1_models_1_1_funciones =
[
    [ "cambiarFormatoFecha", "class_app_1_1_models_1_1_funciones.html#a50c75558ddd5197352b8ab05f75b436c", null ],
    [ "comprobarPassword", "class_app_1_1_models_1_1_funciones.html#a252c3fd8914eb14c4e34842b3dffe3d3", null ],
    [ "formatearFechaHora", "class_app_1_1_models_1_1_funciones.html#a5d0ed3b9e14786d26b1eb02d0f4df2bf", null ],
    [ "mostrarProvincias", "class_app_1_1_models_1_1_funciones.html#ae5e01401f6d31b5600e2916e8b430e86", null ],
    [ "telefonoValido", "class_app_1_1_models_1_1_funciones.html#affaf620907ad5530cabac385b82ba542", null ],
    [ "validarNif", "class_app_1_1_models_1_1_funciones.html#a3848aef567bb27a3d9f770c31fe90e80", null ],
    [ "verErrores", "class_app_1_1_models_1_1_funciones.html#a538d8998a1cb621aea4a0424d7037eae", null ],
    [ "$errores", "class_app_1_1_models_1_1_funciones.html#a0e4625316e78f2744082e3d076e31b3c", null ],
    [ "$provincias", "class_app_1_1_models_1_1_funciones.html#a1d817d313e2d216ad1759ebce1990fa4", null ]
];