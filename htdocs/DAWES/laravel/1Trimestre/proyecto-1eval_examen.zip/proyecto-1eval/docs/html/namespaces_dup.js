var namespaces_dup =
[
    [ "App", "namespace_app.html", "namespace_app" ],
    [ "Config", "namespace_config.html", null ]
];