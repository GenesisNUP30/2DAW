var class_app_1_1_models_1_1_d_b =
[
    [ "__clone", "class_app_1_1_models_1_1_d_b.html#a65f58787ba7c5573eee7b826e354a132", null ],
    [ "__construct", "class_app_1_1_models_1_1_d_b.html#abc045c8a830d4b613c46ff02c22d5016", null ],
    [ "Conectar", "class_app_1_1_models_1_1_d_b.html#ad9c60b71285ec039baaf39f091f175ac", null ],
    [ "escape", "class_app_1_1_models_1_1_d_b.html#a0a6871a96528d076517377280877d145", null ],
    [ "getInstance", "class_app_1_1_models_1_1_d_b.html#ad21ae5a79e7513545ddc5b0c56bcb9db", null ],
    [ "LastID", "class_app_1_1_models_1_1_d_b.html#abcbc3d5cd452150c6bf56b94529ef30f", null ],
    [ "LeeRegistro", "class_app_1_1_models_1_1_d_b.html#a1a127be89f1465b6a389d3ceb25f755d", null ],
    [ "query", "class_app_1_1_models_1_1_d_b.html#a2facf61f010643b18f2e1257f41fa2b1", null ],
    [ "RegistroActual", "class_app_1_1_models_1_1_d_b.html#a8c9707a442fdd06e64449ca9abeb663e", null ],
    [ "$_instance", "class_app_1_1_models_1_1_d_b.html#aa921105840c6708a8c14039e507445f3", null ],
    [ "$base_datos", "class_app_1_1_models_1_1_d_b.html#a4c247ae621d20a548c944e10d36e8ac0", null ],
    [ "$link", "class_app_1_1_models_1_1_d_b.html#af9c7d7b0f6b3db45327b54d27455dd53", null ],
    [ "$regActual", "class_app_1_1_models_1_1_d_b.html#aaecbeda3ccf3aa04c2942c209f9858b4", null ],
    [ "$result", "class_app_1_1_models_1_1_d_b.html#a6352dd828274faf1d2b6990715e2d252", null ]
];