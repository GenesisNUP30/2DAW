var class_app_1_1_models_1_1_user =
[
    [ "casts", "class_app_1_1_models_1_1_user.html#ac9545b970a624867290beb22615cebe0", null ],
    [ "$fillable", "class_app_1_1_models_1_1_user.html#a1c460dfee2ba912e187f5475dc54fac3", null ],
    [ "$hidden", "class_app_1_1_models_1_1_user.html#ab0c168b8631888e590af403cd66418f8", null ]
];