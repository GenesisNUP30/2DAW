var class_app_1_1_models_1_1_tareas =
[
    [ "__construct", "class_app_1_1_models_1_1_tareas.html#a24d0e8e3dbbb16cfe28af07ddc417a0c", null ],
    [ "actualizarTarea", "class_app_1_1_models_1_1_tareas.html#a577b3fc938fb92f3545ea961b538abf4", null ],
    [ "completarTarea", "class_app_1_1_models_1_1_tareas.html#a5d6996570acc3052a7c293435d6439c3", null ],
    [ "eliminarTarea", "class_app_1_1_models_1_1_tareas.html#ae72434b2bfb2b1e4e081ba563585d926", null ],
    [ "listarTareas", "class_app_1_1_models_1_1_tareas.html#a2af0eaab61563699ff499aeaab9cdae2", null ],
    [ "obtenerTareaPorId", "class_app_1_1_models_1_1_tareas.html#ae5d113f25ff4b1a29022e4c4ba046aed", null ],
    [ "registraAlta", "class_app_1_1_models_1_1_tareas.html#ac5b8326ec3b6e12b42b1900290b147f7", null ],
    [ "$bd", "class_app_1_1_models_1_1_tareas.html#a0b24fec2d479d380e103a24627ff0592", null ]
];