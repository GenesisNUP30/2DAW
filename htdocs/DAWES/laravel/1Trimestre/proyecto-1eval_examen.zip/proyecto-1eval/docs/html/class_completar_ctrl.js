var class_completar_ctrl =
[
    [ "completar", "class_completar_ctrl.html#aef14068589c17904f57491324b901cb3", null ],
    [ "filtraDatos", "class_completar_ctrl.html#a9850668c310deb50c5b84cac5e109118", null ],
    [ "mostrarFormulario", "class_completar_ctrl.html#a5d91287d5b7052e55f3d861c5dfa71ec", null ]
];