var class_app_1_1_http_1_1_controllers_1_1_eliminar_usuario_ctrl =
[
    [ "confirmar", "class_app_1_1_http_1_1_controllers_1_1_eliminar_usuario_ctrl.html#a0b699a6bb3cd91d5ea01f6df7f72e95c", null ],
    [ "eliminar", "class_app_1_1_http_1_1_controllers_1_1_eliminar_usuario_ctrl.html#ad5e4c88743e0769c86d690f68c40c040", null ]
];