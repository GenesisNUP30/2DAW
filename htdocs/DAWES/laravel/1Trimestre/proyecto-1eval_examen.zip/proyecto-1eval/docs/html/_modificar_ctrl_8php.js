var _modificar_ctrl_8php =
[
    [ "App::Http::Controllers::ModificarCtrl", "class_app_1_1_http_1_1_controllers_1_1_modificar_ctrl.html", "class_app_1_1_http_1_1_controllers_1_1_modificar_ctrl" ]
];