var globals_vars =
[
    [ "_", "globals_vars.html", null ],
    [ "a", "globals_vars_a.html", null ],
    [ "b", "globals_vars_b.html", null ],
    [ "c", "globals_vars_c.html", null ],
    [ "d", "globals_vars_d.html", null ],
    [ "e", "globals_vars_e.html", null ],
    [ "g", "globals_vars_g.html", null ],
    [ "h", "globals_vars_h.html", null ],
    [ "i", "globals_vars_i.html", null ],
    [ "l", "globals_vars_l.html", null ],
    [ "m", "globals_vars_m.html", null ],
    [ "o", "globals_vars_o.html", null ],
    [ "p", "globals_vars_p.html", null ],
    [ "r", "globals_vars_r.html", null ],
    [ "s", "globals_vars_s.html", null ],
    [ "t", "globals_vars_t.html", null ],
    [ "v", "globals_vars_v.html", null ],
    [ "w", "globals_vars_w.html", null ]
];