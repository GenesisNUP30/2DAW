var class_app_1_1_models_1_1_usuarios =
[
    [ "__construct", "class_app_1_1_models_1_1_usuarios.html#a9d6321e34ecd4e259082ae17e4013c5d", null ],
    [ "actualizarUsuario", "class_app_1_1_models_1_1_usuarios.html#ac7b98ba47fd57279855da662af6b9b6c", null ],
    [ "eliminarUsuario", "class_app_1_1_models_1_1_usuarios.html#a00dd6d31fcbc115dd579e12dd157a73f", null ],
    [ "listarUsuarios", "class_app_1_1_models_1_1_usuarios.html#aa96c419ba904a072802cb45fb25bee16", null ],
    [ "obtenerUsuarioPorId", "class_app_1_1_models_1_1_usuarios.html#a35db71a38b5a6ac18df7559becec4cb7", null ],
    [ "registraUsuario", "class_app_1_1_models_1_1_usuarios.html#ad556032cca4e54d4fa1add22ab977634", null ],
    [ "usuarioExiste", "class_app_1_1_models_1_1_usuarios.html#ab246090a67081dfc99d32d2382f23cf5", null ],
    [ "$bd", "class_app_1_1_models_1_1_usuarios.html#ad08bbcfaa2673a20746d59745385d890", null ]
];