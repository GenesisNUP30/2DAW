

<?php $__env->startSection('titulo', 'Login'); ?>
<?php $__env->startSection('estilos'); ?>
<style>
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cuerpo'); ?>
<div class="container">
    <h1>Introduce tus credenciales para iniciar sesión</h1>
    <?php if(isset($error)): ?>
    <div>
        <?php echo e($error); ?>

    </div>
    <?php endif; ?>
    <form method="post">
        <div>
            <label for="usuario">Usuario</label>
            <input type="text" id="usuario" name="usuario">
        </div>
        <div>
            <label for="password">Contraseña</label>
            <input type="password" id="password" name="password">
        </div>
        <button type="submit">Iniciar Sesión</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla01', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ushca\OneDrive\Escritorio\Génesis\2DAW\htdocs\DAWES\laravel\proyecto-1eval\resources\views/login.blade.php ENDPATH**/ ?>