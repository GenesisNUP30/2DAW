<?php

return [
    'servidor' => 'localhost',
    'usuario' => 'root',
    'password' => '',
    'base_datos' => 'proyecto_1eval'
];