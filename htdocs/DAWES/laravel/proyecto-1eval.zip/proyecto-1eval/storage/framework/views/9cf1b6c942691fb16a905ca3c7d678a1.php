

<?php $__env->startSection('titulo', 'Eliminar Tarea'); ?>

<?php $__env->startSection('cuerpo'); ?>
   <h1>Eliminar Tarea</h1>

   <p>¿Estás seguro de que deseas eliminar la tarea de <strong><?php echo e($tarea['persona_contacto']); ?></strong>?</p>

   <form action="<?php echo e(url('eliminar/' . $tarea['id'])); ?>" method="POST">
        <?php echo method_field('DELETE'); ?>
        <input type="submit" value="Sí, eliminar">
        <a href="<?php echo e(url('/')); ?>">Cancelar</a>
   </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla01', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ushca\Desktop\Génesis\2DAW\htdocs\DAWES\laravel\proyecto-1eval\resources\views/eliminar.blade.php ENDPATH**/ ?>